package com.donutgambler;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DonutGambler implements ClientModInitializer {
	/**
	 * Matches the "X paid you $Y" system message. If DonutSMP words it differently,
	 * change this pattern (group 1 = player name, group 2 = amount).
	 */
	static final Pattern PAID_YOU = Pattern.compile("^(\\w{3,16}) (?:paid|sent) you \\$?([\\d.,]+[kKmMbBtT]?)");

	public static Ledger ledger;
	public static final List<Pending> PENDING = new CopyOnWriteArrayList<>();

	private static KeyBinding openKey;

	@Override
	public void onInitializeClient() {
		ledger = Ledger.load();

		openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.donutgambler.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, KeyBinding.Category.MISC));

		ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
			if (overlay) return;
			onChat(message.getString());
		});

		// clickable "Gambler" button on the chat, inventory and pause screens
		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (screen instanceof ChatScreen || screen instanceof InventoryScreen
				|| screen instanceof GameMenuScreen) {
				Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Gambler"),
					b -> client.setScreen(new MenuScreen())).dimensions(4, 4, 60, 18).build());
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			Auction.tick(mc);
			while (openKey.wasPressed()) {
				if (mc.currentScreen == null && mc.player != null) {
					mc.setScreen(new MenuScreen());
				}
			}
		});
	}

	private static void onChat(String text) {
		Matcher m = PAID_YOU.matcher(text.trim());
		if (!m.find()) return;
		String player = m.group(1);
		long amount;
		try {
			amount = Money.parse(m.group(2));
		} catch (NumberFormatException e) {
			return;
		}
		ledger.addIncome(amount);

		if (Auction.active()) {
			Auction.bid(player, amount);
			return;
		}

		PENDING.add(new Pending(player, amount, amount * 2, false));
		say(Text.literal("[DG] " + player + " paid $" + Money.format(amount)
			+ " - open the menu (G) to pay 2x or skip."));
	}

	/** Sends /pay and records the payout in today's ledger. */
	public static void pay(String player, long amount) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null) return;
		mc.player.networkHandler.sendChatCommand("pay " + player + " " + amount);
		ledger.addPayout(amount);
		say(Text.literal("[DG] Paid " + player + " $" + Money.format(amount)));
	}

	public static void say(Text t) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player != null) mc.player.sendMessage(t, false);
	}
}
