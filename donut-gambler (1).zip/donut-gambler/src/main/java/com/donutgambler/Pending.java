package com.donutgambler;

/** Something waiting in the menu: a payment you may pay back double, or an auction refund. */
public record Pending(String player, long received, long payAmount, boolean refund) {
	public String label() {
		if (refund) {
			return "Refund " + player + " $" + Money.format(payAmount);
		}
		return player + " paid $" + Money.format(received) + "  -  Pay 2x $" + Money.format(payAmount);
	}
}
