package com.donutgambler;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

/** Daily profit/loss ledger, saved to config/donutgambler.json. */
public class Ledger {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public String date = LocalDate.now().toString();
	public long income;
	public long payouts;
	public int payments;
	public Map<String, Long> history = new LinkedHashMap<>();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("donutgambler.json");
	}

	public static Ledger load() {
		try {
			if (Files.exists(file())) {
				Ledger l = GSON.fromJson(Files.readString(file()), Ledger.class);
				if (l != null) {
					if (l.history == null) l.history = new LinkedHashMap<>();
					l.rollover();
					return l;
				}
			}
		} catch (Exception ignored) {}
		return new Ledger();
	}

	public void save() {
		try {
			Files.writeString(file(), GSON.toJson(this));
		} catch (IOException ignored) {}
	}

	private void rollover() {
		String today = LocalDate.now().toString();
		if (!today.equals(date)) {
			history.put(date, income - payouts);
			date = today;
			income = 0;
			payouts = 0;
			payments = 0;
		}
	}

	public void addIncome(long amount) {
		rollover();
		income += amount;
		payments++;
		save();
	}

	public void addPayout(long amount) {
		rollover();
		payouts += amount;
		save();
	}

	public long net() {
		rollover();
		return income - payouts;
	}

	public void reset() {
		income = 0;
		payouts = 0;
		payments = 0;
		save();
	}
}
