package com.donutgambler;

import java.util.Locale;

public final class Money {
	private Money() {}

	/** Parses "1500", "$1,500", "1.5k", "2M", "3b", "1t" into a whole number. */
	public static long parse(String raw) {
		String s = raw.trim().toLowerCase(Locale.ROOT).replace("$", "").replace(",", "");
		long mult = 1;
		if (!s.isEmpty()) {
			switch (s.charAt(s.length() - 1)) {
				case 'k' -> mult = 1_000L;
				case 'm' -> mult = 1_000_000L;
				case 'b' -> mult = 1_000_000_000L;
				case 't' -> mult = 1_000_000_000_000L;
				default -> {}
			}
			if (mult != 1) s = s.substring(0, s.length() - 1);
		}
		return Math.round(Double.parseDouble(s) * mult);
	}

	public static String format(long v) {
		String sign = v < 0 ? "-" : "";
		double a = Math.abs((double) v);
		if (a >= 1e12) return sign + trim(a / 1e12) + "T";
		if (a >= 1e9) return sign + trim(a / 1e9) + "B";
		if (a >= 1e6) return sign + trim(a / 1e6) + "M";
		if (a >= 1e3) return sign + trim(a / 1e3) + "K";
		return sign + (long) a;
	}

	private static String trim(double d) {
		String s = String.format(Locale.ROOT, "%.2f", d);
		if (s.contains(".")) s = s.replaceAll("0+$", "").replaceAll("\\.$", "");
		return s;
	}
}
