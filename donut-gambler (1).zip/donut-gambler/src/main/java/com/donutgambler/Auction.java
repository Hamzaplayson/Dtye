package com.donutgambler;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

/**
 * One auction at a time. While it runs, every payment you receive counts as a bid
 * (a player's bids add up). Highest total at the end wins if it reaches the worth you set.
 */
public final class Auction {
	private Auction() {}

	private static final int[] ANNOUNCE_AT = {600, 300, 60, 30, 10};

	static boolean active;
	static String itemName = "";
	static long worth;
	static long endAt;
	static int lastAnnounce;
	static int totalSec = 1;
	static String leader;
	static final Map<String, Long> bids = new HashMap<>();

	public static boolean active() {
		return active;
	}

	public static void start(String name, long minBid, int minutes) {
		active = true;
		itemName = name;
		worth = minBid;
		endAt = System.currentTimeMillis() + minutes * 60_000L;
		totalSec = minutes * 60;
		lastAnnounce = minutes * 60;
		leader = null;
		bids.clear();
		chat("[AUCTION] " + name + " | worth/min bid: $" + Money.format(minBid) + " | ends in " + minutes
			+ "m | /pay me to bid, highest total wins!");
	}

	public static void bid(String player, long amount) {
		long total = bids.merge(player, amount, Long::sum);
		Long top = leader == null ? null : bids.get(leader);
		if (top == null || total > top) {
			leader = player;
			chat("[AUCTION] " + player + " leads " + itemName + " with $" + Money.format(total));
		}
		DonutGambler.say(Text.literal("[Auction] " + player + " bid $" + Money.format(amount)
			+ " (total $" + Money.format(total) + ")"));
	}

	public static void tick(MinecraftClient mc) {
		if (!active || mc.player == null) return;
		long remMs = endAt - System.currentTimeMillis();
		if (remMs <= 0) {
			finish();
			return;
		}
		int remSec = (int) (remMs / 1000);
		for (int t : ANNOUNCE_AT) {
			if (remSec <= t && lastAnnounce > t) {
				lastAnnounce = t;
				String top = leader == null ? "no bids yet" : leader + " $" + Money.format(bids.get(leader));
				chat("[AUCTION] " + itemName + " ends in " + (t >= 60 ? (t / 60) + "m" : t + "s") + " | top: " + top);
				break;
			}
		}
	}

	public static int secondsLeft() {
		return (int) Math.max(0, (endAt - System.currentTimeMillis()) / 1000);
	}

	public static void finish() {
		if (!active) return;
		active = false;
		boolean sold = leader != null && bids.get(leader) >= worth;
		if (sold) {
			chat("[AUCTION] SOLD! " + leader + " wins " + itemName + " for $" + Money.format(bids.get(leader)));
			DonutGambler.say(Text.literal("[Auction] Hand " + itemName + " to " + leader
				+ ". Refunds for the others are in the menu."));
		} else {
			chat("[AUCTION] " + itemName + " not sold (min $" + Money.format(worth) + " not reached).");
			DonutGambler.say(Text.literal("[Auction] No winner. Refunds are in the menu."));
		}
		for (Map.Entry<String, Long> e : bids.entrySet()) {
			if (!sold || !e.getKey().equals(leader)) {
				DonutGambler.PENDING.add(new Pending(e.getKey(), e.getValue(), e.getValue(), true));
			}
		}
	}

	public static void cancel() {
		if (!active) return;
		active = false;
		chat("[AUCTION] " + itemName + " cancelled.");
		for (Map.Entry<String, Long> e : bids.entrySet()) {
			DonutGambler.PENDING.add(new Pending(e.getKey(), e.getValue(), e.getValue(), true));
		}
	}

	static void chat(String msg) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player != null) mc.player.networkHandler.sendChatMessage(msg);
	}
}
