package com.donutgambler;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** The one menu: Payments (pay 2x / skip), Auction (any item), Stats (daily profit). */
public class MenuScreen extends Screen {
	private enum Tab { PAYMENTS, AUCTION, STATS }

	// layout
	private static final int PANEL_W = 340;
	private static final int PAD = 12;
	private static final int HEADER_H = 30;
	private static final int ROWS = 4;
	private static final int PAY_ROWS = 6;

	// palette
	private static final int BG = 0xF0121620;
	private static final int BORDER = 0xFF2C3446;
	private static final int HEADER = 0xFF1B2130;
	private static final int CARD = 0xFF1C2230;
	private static final int CARD_ALT = 0xFF222A3A;
	private static final int GOLD = 0xFFFFC857;
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFF8B95A8;
	private static final int GREEN = 0xFF4ADE80;
	private static final int RED = 0xFFF87171;
	private static final int TRACK = 0xFF2A3244;

	// kept between openings
	private static Tab tab = Tab.PAYMENTS;
	private static String search = "";
	private static String worthText = "";
	private static String minutesText = "10";
	private static Item selected;
	private static int page;
	private static String error = "";

	private static List<Item> allItems;

	private final List<ButtonWidget> resultButtons = new ArrayList<>();
	private List<Item> filtered = new ArrayList<>();
	private int px; // panel left
	private int py; // panel top
	private int cx; // content left
	private int cy; // content top
	private int cw; // content width
	private int panelH;
	private boolean builtAuctionActive;
	private int builtPendingSize;

	public MenuScreen() {
		super(Text.literal("Donut Gambler"));
	}

	private static List<Item> items() {
		if (allItems == null) {
			allItems = new ArrayList<>();
			Registries.ITEM.stream().filter(i -> i != Items.AIR).forEach(allItems::add);
			allItems.sort(Comparator.comparing(i -> i.getName().getString().toLowerCase(Locale.ROOT)));
		}
		return allItems;
	}

	@Override
	protected void init() {
		panelH = 268;
		px = (width - PANEL_W) / 2;
		py = Math.max(4, (height - panelH) / 2);
		cx = px + PAD;
		cw = PANEL_W - PAD * 2;
		cy = py + HEADER_H + 28;
		builtAuctionActive = Auction.active();
		builtPendingSize = DonutGambler.PENDING.size();
		resultButtons.clear();

		Tab[] tabs = Tab.values();
		String[] names = {"Payments", "Auction", "Stats"};
		int tw = cw / 3;
		for (int i = 0; i < tabs.length; i++) {
			Tab t = tabs[i];
			String label = names[i];
			if (t == Tab.PAYMENTS && !DonutGambler.PENDING.isEmpty()) {
				label += " (" + DonutGambler.PENDING.size() + ")";
			}
			ButtonWidget b = ButtonWidget.builder(Text.literal(label), btn -> {
				tab = t;
				error = "";
				clearAndInit();
			}).dimensions(cx + i * tw, py + HEADER_H + 4, tw - 3, 18).build();
			b.active = tab != t;
			addDrawableChild(b);
		}

		switch (tab) {
			case PAYMENTS -> initPayments();
			case AUCTION -> {
				if (Auction.active()) initAuctionRunning();
				else initAuctionSetup();
			}
			case STATS -> initStats();
		}
	}

	// ---------- Payments ----------

	private void initPayments() {
		List<Pending> list = DonutGambler.PENDING;
		int shown = Math.min(list.size(), PAY_ROWS);
		for (int i = 0; i < shown; i++) {
			Pending p = list.get(i);
			int y = cy + i * 26;
			String payLabel = p.refund() ? "Refund $" + Money.format(p.payAmount())
				: "Pay 2x  $" + Money.format(p.payAmount());
			addDrawableChild(ButtonWidget.builder(Text.literal(payLabel), b -> {
				DonutGambler.pay(p.player(), p.payAmount());
				DonutGambler.PENDING.remove(p);
				clearAndInit();
			}).dimensions(cx + cw - 128, y + 3, 84, 18).build());
			addDrawableChild(ButtonWidget.builder(Text.literal(p.refund() ? "Dismiss" : "No"), b -> {
				DonutGambler.PENDING.remove(p);
				clearAndInit();
			}).dimensions(cx + cw - 41, y + 3, 40, 18).build());
		}
		if (!list.isEmpty()) {
			addDrawableChild(ButtonWidget.builder(Text.literal("Clear all"), b -> {
				DonutGambler.PENDING.clear();
				clearAndInit();
			}).dimensions(cx + cw - 70, py + panelH - 28, 70, 18).build());
		}
	}

	// ---------- Auction ----------

	private void initAuctionSetup() {
		TextFieldWidget searchField = new TextFieldWidget(textRenderer, cx, cy, cw, 18, Text.literal("Search"));
		searchField.setPlaceholder(Text.literal("Search any item..."));
		searchField.setMaxLength(60);
		searchField.setText(search);
		searchField.setChangedListener(s -> {
			search = s;
			page = 0;
			refreshResults();
		});
		addDrawableChild(searchField);

		for (int i = 0; i < ROWS; i++) {
			int idx = i;
			ButtonWidget b = ButtonWidget.builder(Text.literal(""), btn -> {
				int real = page * ROWS + idx;
				if (real < filtered.size()) selected = filtered.get(real);
			}).dimensions(cx + 22, cy + 22 + i * 19, cw - 22, 18).build();
			resultButtons.add(b);
			addDrawableChild(b);
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
			if (page > 0) page--;
			refreshResults();
		}).dimensions(cx, cy + 100, 30, 16).build());
		addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
			if ((page + 1) * ROWS < filtered.size()) page++;
			refreshResults();
		}).dimensions(cx + cw - 30, cy + 100, 30, 16).build());

		int half = cw / 2;
		TextFieldWidget worth = new TextFieldWidget(textRenderer, cx, cy + 146, half - 4, 18, Text.literal("Worth"));
		worth.setPlaceholder(Text.literal("e.g. 5M"));
		worth.setText(worthText);
		worth.setChangedListener(s -> worthText = s);
		addDrawableChild(worth);

		TextFieldWidget minutes = new TextFieldWidget(textRenderer, cx + half, cy + 146, half, 18, Text.literal("Minutes"));
		minutes.setText(minutesText);
		minutes.setChangedListener(s -> minutesText = s);
		addDrawableChild(minutes);

		addDrawableChild(ButtonWidget.builder(Text.literal("Start auction"), b -> startAuction())
			.dimensions(cx, cy + 170, cw, 20).build());

		refreshResults();
	}

	private void refreshResults() {
		String q = search.trim().toLowerCase(Locale.ROOT);
		filtered = new ArrayList<>();
		for (Item i : items()) {
			if (q.isEmpty()
				|| i.getName().getString().toLowerCase(Locale.ROOT).contains(q)
				|| Registries.ITEM.getId(i).getPath().contains(q.replace(' ', '_'))) {
				filtered.add(i);
			}
		}
		int maxPage = Math.max(0, (filtered.size() - 1) / ROWS);
		if (page > maxPage) page = maxPage;
		for (int i = 0; i < resultButtons.size(); i++) {
			int real = page * ROWS + i;
			ButtonWidget b = resultButtons.get(i);
			if (real < filtered.size()) {
				b.setMessage(filtered.get(real).getName());
				b.visible = true;
			} else {
				b.visible = false;
			}
		}
	}

	private void startAuction() {
		if (selected == null) {
			error = "Pick an item first.";
			return;
		}
		long worth;
		int mins;
		try {
			worth = Money.parse(worthText);
		} catch (NumberFormatException e) {
			error = "Type the worth, like 500K or 5M.";
			return;
		}
		try {
			mins = Integer.parseInt(minutesText.trim());
		} catch (NumberFormatException e) {
			error = "Minutes must be a number.";
			return;
		}
		if (mins < 1 || mins > 1440) {
			error = "Minutes must be 1 to 1440.";
			return;
		}
		error = "";
		Auction.start(selected.getName().getString(), worth, mins);
		clearAndInit();
	}

	private void initAuctionRunning() {
		int half = cw / 2;
		addDrawableChild(ButtonWidget.builder(Text.literal("End now"), b -> {
			Auction.finish();
			clearAndInit();
		}).dimensions(cx, py + panelH - 30, half - 3, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Cancel + refund"), b -> {
			Auction.cancel();
			clearAndInit();
		}).dimensions(cx + half, py + panelH - 30, half, 20).build());
	}

	// ---------- Stats ----------

	private void initStats() {
		addDrawableChild(ButtonWidget.builder(Text.literal("Reset today"), b -> DonutGambler.ledger.reset())
			.dimensions(cx, py + panelH - 30, 90, 20).build());
	}

	// ---------- Live refresh ----------

	@Override
	public void tick() {
		if (Auction.active() != builtAuctionActive || DonutGambler.PENDING.size() != builtPendingSize) {
			clearAndInit();
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	// ---------- Drawing ----------

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.renderBackground(ctx, mouseX, mouseY, delta);
		// panel with border and header
		ctx.fill(px - 1, py - 1, px + PANEL_W + 1, py + panelH + 1, BORDER);
		ctx.fill(px, py, px + PANEL_W, py + panelH, BG);
		ctx.fill(px, py, px + PANEL_W, py + HEADER_H, HEADER);
		ctx.fill(px, py + HEADER_H, px + PANEL_W, py + HEADER_H + 1, GOLD);
		// content area background
		ctx.fill(px + 4, py + HEADER_H + 26, px + PANEL_W - 4, py + panelH - 4, 0x30000000);
		// active tab underline
		int tw = cw / 3;
		int idx = tab.ordinal();
		ctx.fill(cx + idx * tw, py + HEADER_H + 22, cx + idx * tw + tw - 3, py + HEADER_H + 24, GOLD);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);

		// header
		ctx.drawItem(new ItemStack(Items.GOLD_INGOT), px + 10, py + 7);
		ctx.drawTextWithShadow(textRenderer, "Donut Gambler", px + 30, py + 7, GOLD);
		ctx.drawTextWithShadow(textRenderer, "DonutSMP toolkit", px + 30, py + 18, GRAY);
		long net = DonutGambler.ledger.net();
		String pill = (net >= 0 ? "+$" : "-$") + Money.format(Math.abs(net)) + " today";
		int pw = textRenderer.getWidth(pill);
		ctx.drawTextWithShadow(textRenderer, pill, px + PANEL_W - pw - 12, py + 11, net >= 0 ? GREEN : RED);

		switch (tab) {
			case PAYMENTS -> renderPayments(ctx);
			case AUCTION -> {
				if (Auction.active()) renderAuctionRunning(ctx);
				else renderAuctionSetup(ctx);
			}
			case STATS -> renderStats(ctx);
		}
	}

	private void renderPayments(DrawContext ctx) {
		List<Pending> list = DonutGambler.PENDING;
		if (list.isEmpty()) {
			ctx.drawCenteredTextWithShadow(textRenderer, "No payments waiting", px + PANEL_W / 2, cy + 50, GRAY);
			ctx.drawCenteredTextWithShadow(textRenderer, "When someone pays you, it shows up here.",
				px + PANEL_W / 2, cy + 64, 0xFF5E687C);
			return;
		}
		int shown = Math.min(list.size(), PAY_ROWS);
		for (int i = 0; i < shown; i++) {
			Pending p = list.get(i);
			int y = cy + i * 26;
			ctx.fill(cx, y, cx + cw, y + 24, i % 2 == 0 ? CARD : CARD_ALT);
			ctx.fill(cx, y, cx + 2, y + 24, p.refund() ? RED : GOLD);
			ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(p.player(), 90), cx + 8, y + 4, WHITE);
			String sub = p.refund() ? "bid to refund" : "paid $" + Money.format(p.received());
			ctx.drawTextWithShadow(textRenderer, sub, cx + 8, y + 14, GRAY);
		}
		if (list.size() > PAY_ROWS) {
			ctx.drawTextWithShadow(textRenderer, "+" + (list.size() - PAY_ROWS) + " more",
				cx, py + panelH - 24, GRAY);
		}
	}

	private void renderAuctionSetup(DrawContext ctx) {
		for (int i = 0; i < ROWS; i++) {
			int real = page * ROWS + i;
			if (real < filtered.size()) {
				Item it = filtered.get(real);
				int y = cy + 22 + i * 19;
				ctx.drawItem(new ItemStack(it), cx + 3, y + 1);
				if (it == selected) {
					ctx.drawBorder(cx + 22, y, cw - 22, 18, GOLD);
				}
			}
		}
		int pages = Math.max(1, (filtered.size() + ROWS - 1) / ROWS);
		ctx.drawCenteredTextWithShadow(textRenderer, (page + 1) + " / " + pages + "   " + filtered.size() + " items",
			px + PANEL_W / 2, cy + 104, GRAY);

		// selected card
		ctx.fill(cx, cy + 120, cx + cw, cy + 138, CARD);
		ctx.fill(cx, cy + 120, cx + 2, cy + 138, selected == null ? GRAY : GOLD);
		if (selected != null) {
			ctx.drawItem(new ItemStack(selected), cx + 6, cy + 121);
			ctx.drawTextWithShadow(textRenderer, selected.getName().getString(), cx + 26, cy + 125, WHITE);
		} else {
			ctx.drawTextWithShadow(textRenderer, "No item selected", cx + 8, cy + 125, GRAY);
		}

		int half = cw / 2;
		ctx.drawTextWithShadow(textRenderer, "Worth / min bid", cx, cy + 139 + 0, GRAY);
		ctx.drawTextWithShadow(textRenderer, "Timer (minutes)", cx + half, cy + 139, GRAY);

		if (!error.isEmpty()) {
			ctx.drawCenteredTextWithShadow(textRenderer, error, px + PANEL_W / 2, cy + 196, RED);
		}
	}

	private void renderAuctionRunning(DrawContext ctx) {
		int s = Auction.secondsLeft();
		ctx.drawTextWithShadow(textRenderer, Auction.itemName, cx, cy + 2, GOLD);
		ctx.drawTextWithShadow(textRenderer, "Min bid: $" + Money.format(Auction.worth), cx, cy + 14, GRAY);

		String time = (s / 60) + "m " + (s % 60) + "s";
		ctx.drawTextWithShadow(textRenderer, time, cx + cw - textRenderer.getWidth(time), cy + 2, WHITE);

		// timer bar
		float frac = Math.max(0f, Math.min(1f, s / (float) Math.max(1, Auction.totalSec)));
		ctx.fill(cx, cy + 28, cx + cw, cy + 34, TRACK);
		ctx.fill(cx, cy + 28, cx + (int) (cw * frac), cy + 34, frac > 0.2f ? GREEN : RED);

		ctx.drawTextWithShadow(textRenderer, "Top bids", cx, cy + 44, GRAY);
		List<Map.Entry<String, Long>> sorted = new ArrayList<>(Auction.bids.entrySet());
		sorted.sort((a, b) -> Long.compare(b.getValue(), a.getValue()));
		if (sorted.isEmpty()) {
			ctx.drawTextWithShadow(textRenderer, "Waiting for the first payment...", cx, cy + 60, 0xFF5E687C);
		}
		for (int i = 0; i < Math.min(5, sorted.size()); i++) {
			var e = sorted.get(i);
			int y = cy + 56 + i * 20;
			ctx.fill(cx, y, cx + cw, y + 18, i == 0 ? 0xFF2B2A18 : (i % 2 == 0 ? CARD : CARD_ALT));
			if (i == 0) ctx.fill(cx, y, cx + 2, y + 18, GOLD);
			ctx.drawTextWithShadow(textRenderer, "#" + (i + 1), cx + 8, y + 5, i == 0 ? GOLD : GRAY);
			ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(e.getKey(), 140), cx + 28, y + 5, WHITE);
			String amt = "$" + Money.format(e.getValue());
			ctx.drawTextWithShadow(textRenderer, amt, cx + cw - textRenderer.getWidth(amt) - 6, y + 5,
				i == 0 ? GREEN : WHITE);
		}
	}

	private void renderStats(DrawContext ctx) {
		Ledger l = DonutGambler.ledger;
		long net = l.net();
		int third = cw / 3;

		statCard(ctx, cx, cy, third - 4, "IN", "$" + Money.format(l.income), l.payments + " payments", WHITE);
		statCard(ctx, cx + third, cy, third - 4, "OUT", "$" + Money.format(l.payouts), "paid back", WHITE);
		statCard(ctx, cx + third * 2, cy, third, net >= 0 ? "PROFIT" : "LOSS",
			"$" + Money.format(Math.abs(net)), l.date, net >= 0 ? GREEN : RED);

		ctx.drawTextWithShadow(textRenderer, "Last days", cx, cy + 56, GRAY);

		List<Map.Entry<String, Long>> hist = new ArrayList<>(l.history.entrySet());
		int n = Math.min(7, hist.size());
		if (n == 0) {
			ctx.drawTextWithShadow(textRenderer, "History fills in after your first full day.", cx, cy + 74, 0xFF5E687C);
			return;
		}
		List<Map.Entry<String, Long>> recent = hist.subList(hist.size() - n, hist.size());
		long max = 1;
		for (var e : recent) max = Math.max(max, Math.abs(e.getValue()));

		int baseY = cy + 112; // zero line
		int maxH = 36;
		int slot = cw / 7;
		ctx.fill(cx, baseY, cx + cw, baseY + 1, TRACK);
		for (int i = 0; i < n; i++) {
			var e = recent.get(i);
			long v = e.getValue();
			int h = (int) Math.max(2, Math.abs(v) * maxH / max);
			int bx = cx + i * slot + 6;
			int bw = slot - 12;
			if (v >= 0) {
				ctx.fill(bx, baseY - h, bx + bw, baseY, GREEN);
			} else {
				ctx.fill(bx, baseY + 1, bx + bw, baseY + 1 + h, RED);
			}
			String day = e.getKey().length() >= 10 ? e.getKey().substring(5) : e.getKey();
			ctx.drawTextWithShadow(textRenderer, day, bx + bw / 2 - textRenderer.getWidth(day) / 2,
				baseY + maxH + 6, GRAY);
		}
	}

	private void statCard(DrawContext ctx, int x, int y, int w, String label, String value, String sub, int color) {
		ctx.fill(x, y, x + w, y + 44, CARD);
		ctx.fill(x, y, x + w, y + 2, color == WHITE ? GOLD : color);
		ctx.drawTextWithShadow(textRenderer, label, x + 6, y + 7, GRAY);
		ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(value, w - 10), x + 6, y + 19, color);
		ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(sub, w - 10), x + 6, y + 32, 0xFF5E687C);
	}
}
